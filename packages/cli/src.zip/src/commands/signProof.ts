import type { Command } from "commander"
import { Wallet } from "ethers"
import {
  getCheckoutSession,
  buildAgentPaymentProofFromSession,
  signAgentPaymentProofV2,
} from "@valuya/agent"

export function cmdSignProof(program: Command) {
  program
    .command("sign-proof")
    .description(
      "Fetch session, build deterministic AgentPaymentProofV2, sign it",
    )
    .requiredOption("--base <url>")
    .requiredOption("--tenant_token <token>")
    .requiredOption("--pk <privateKey>")
    .requiredOption("--session-id <id>")
    .requiredOption("--tx-hash <hash>")
    .action(async (opts) => {
      const wallet = new Wallet(opts.pk)

      const cfg = {
        base: String(opts.base),
        tenant_token: String(opts.tenant_token),
      }

      const sessionId = String(opts.sessionId)
      const tx_hash = String(opts.txHash).toLowerCase()

      const session = await getCheckoutSession({ cfg, sessionId })

      const proof = buildAgentPaymentProofFromSession({
        session,
        tx_hash,
      })

      const signature = await signAgentPaymentProofV2(wallet as any, proof)

      console.log(
        JSON.stringify(
          {
            wallet_address: wallet.address.toLowerCase(),
            proof,
            signature,
          },
          null,
          2,
        ),
      )
    })
}
