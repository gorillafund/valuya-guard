export type CheckoutSessionResponse = {
  payment_url: string
  session_id: string
  expires_at?: string
}
