// src/commands/submitTx.ts
import type { Command } from "commander"
import { Wallet } from "ethers"
import chalk from "chalk"

import { getCheckoutSession } from "@valuya/agent"
import { buildAgentPaymentProofFromSession } from "@valuya/agent"
import { signAgentPaymentProofV2 } from "@valuya/agent"
import { submitAgentTx } from "@valuya/agent"

function logStep(msg: string) {
  console.log(chalk.cyan(`→ ${msg}`))
}
function logOk(msg: string) {
  console.log(chalk.green(`✔ ${msg}`))
}

export function cmdSubmitTx(program: Command) {
  program
    .command("submit-tx")
    .description("Submit a tx proof for an existing checkout session")
    .requiredOption("--base <url>")
    .requiredOption("--tenant_token <token>")
    .requiredOption("--pk <privateKey>")
    .requiredOption("--session-id <id>")
    .requiredOption("--tx-hash <hash>")
    .action(async (opts) => {
      const cfg = { base: opts.base, tenant_token: opts.tenant_token }
      const wallet = new Wallet(opts.pk)
      const wallet_address = wallet.address.toLowerCase()

      const sessionId = String(opts.sessionId)
      const tx_hash = String(opts.txHash).toLowerCase()

      logStep("Fetching checkout session (authoritative fields)")
      const session = await getCheckoutSession({ cfg, sessionId })

      logStep("Building proof from session + tx_hash")
      const proof = buildAgentPaymentProofFromSession({ session, tx_hash })

      logStep("Signing proof")
      const signature = await signAgentPaymentProofV2(wallet as any, proof)

      logStep("Submitting proof")
      const res = await submitAgentTx({
        cfg,
        sessionId,
        wallet_address,
        tx_hash,
        signature,
        proof,
      })

      logOk("Submitted")
      console.log(JSON.stringify(res, null, 2))
    })
}
